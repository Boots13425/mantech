const express = require('express');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Session configuration
app.use(session({
    secret: process.env.SESSION_SECRET || 'Admin@123',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false
    }
}));

const pool = require('./db');


// Middleware to check authentication
const requireAuth = (req, res, next) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    next();
};

// ==================== API ROUTES ====================

const internRegistrationRouter = require("./routes/intern-registration")
const attendanceRouter = require("./routes/attendance")
const receiptRouter = require("./routes/receipt-management")
const settingsRouter = require("./routes/settings")
const adminRouter = require("./routes/admin")
const adminsRouter = require("./routes/admins")
const exportRouter = require("./routes/export")
const backupsRouter = require("./routes/backups")
const groupRouter = require("./routes/group-management")
const internManagementRouter = require("./routes/intern-management")


app.use("/api", internRegistrationRouter)
app.use("/api/receipts", receiptRouter)
app.use("/api/attendance", attendanceRouter)
// Mount settings router at /settings (not under /api) so the page is reachable
app.use('/settings', settingsRouter)
// admin endpoints
app.use('/api/admin', adminRouter)
app.use('/api/admins', adminsRouter)
app.use('/api/export', exportRouter)
app.use('/api/backups', backupsRouter)
app.use("/api/groups", groupRouter)
app.use("/api/interns", internManagementRouter)

// Login endpoint
app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    
    try {
        // Validate input
        if (!email || !password) {
            return res.status(400).json({ message: 'Email and password required' });
        }
        
        // Development fallback: allow test credentials
        if (process.env.NODE_ENV === 'development' && email === 'admin@ets-ntech.org' && password === 'Admin@123') {
            req.session.userId = 1;
            req.session.userEmail = email;
            return res.json({
                message: 'Login successful',
                user: {
                    id: 1,
                    email: email
                }
            });
        }
        
        // Get connection from pool
        const connection = await pool.getConnection();
        
        try {
            // Check if user exists
            const [rows] = await connection.query(
                'SELECT id, email, password FROM users WHERE email = ?',
                [email]
            );
            
            if (rows.length === 0) {
                return res.status(401).json({ message: 'Invalid credentials' });
            }
            
            const user = rows[0];
            
            // Compare passwords
            const passwordMatch = await bcrypt.compare(password, user.password);
            
            if (!passwordMatch) {
                return res.status(401).json({ message: 'Invalid credentials' });
            }
            
            // Store user in session
            req.session.userId = user.id;
            req.session.userEmail = user.email;
            
            res.json({
                message: 'Login successful',
                user: {
                    id: user.id,
                    email: user.email,
                    role: user.role
                }
            });
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('Login error:', error);
        const resp = { message: 'Server error' }
        if (process.env.NODE_ENV !== 'production') resp.error = error.message || String(error)
        res.status(500).json(resp);
    }
});

// Check authentication endpoint
app.get('/api/auth/check', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ message: 'Not authenticated' });
    }

    try {
        const connection = await pool.getConnection();
        try {
            const [rows] = await connection.query('SELECT id, email, full_name as name FROM users WHERE id = ?', [req.session.userId]);
            if (rows.length === 0) return res.status(401).json({ message: 'Not authenticated' });
            const user = rows[0];
            // Keep session in sync
            try { req.session.userEmail = user.email } catch (e) {}
            res.json({ authenticated: true, user });
        } finally { connection.release(); }
    } catch (err) {
        console.error('Auth check error', err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Logout endpoint
app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ message: 'Logout failed' });
        }
        res.json({ message: 'Logged out successfully' });
    });
});

// ==================== ERROR HANDLING ====================

// 404 handler
app.use((req, res) => {
    res.status(404).json({ message: 'Not found' });
});

// Error handler
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ message: 'Server error' });
});



// ==================== SERVER START ====================

app.listen(PORT, '0.0.0.0', () => {
    console.log(`
    ╔═══════════════════════════════════════════╗
    ║         MANTech Server Running            ║
    ║     Server: http://localhost:${PORT}      ║
    ║     Environment: ${process.env.NODE_ENV || 'development'}       ║
    ╚═══════════════════════════════════════════╝
    `);
});